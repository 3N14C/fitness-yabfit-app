import { FC } from "react";
import { View } from "react-native";

export const Line: FC = () => {
  return (
    <View className="my-[10px] items-center">
      <View className="bg-black/50 h-[1px]" style={{width: 350}} />
    </View>
  );
};
