import { FC } from "react";
import { View } from "react-native";
import Animated, { FadeInRight } from "react-native-reanimated";

export const MenuBar: FC = () => {
  return (
    <View className="">
      <Animated.View
        entering={FadeInRight.delay(200).springify()}
        className="w-[76px] h-[0.6px] bg-black dark:bg-white mr-[20px]"
      />
      <Animated.View
        entering={FadeInRight.delay(500).springify()}
        className="w-[76px] h-[0.5px] bg-black mt-[15px] dark:bg-white ml-[20px]"
      />
    </View>
  );
};
