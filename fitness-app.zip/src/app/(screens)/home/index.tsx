import { db } from "@/appwrite";
import { Logo } from "@/ui/Logo";
import { COLLECTION_CATEGORY, DATABASE_ID } from "@/constants/appwrite";
import { useAuth } from "@/context/AuthContext";
import { ICategory } from "@/interfaces/category.interface";
import { MenuBar } from "@/ui/MenuBar";
import { TextSlider } from "@/ui/TextSlider";
import { useQuery } from "@tanstack/react-query";
import {
  Button,
  Image,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Navbar } from "@/components/HomeNavbar";
import { ScrollView } from "react-native";
import Animated, { FadeInLeft, FadeInRight } from "react-native-reanimated";

const Index = () => {
  return (
    <SafeAreaView className="flex-1 dark:bg-black bg-white">
      <ScrollView className="">
        <View style={styles.container}>
          <View className="flex-row items-center justify-between">
            <Animated.View entering={FadeInLeft.delay(200).springify()}>
              <Logo />
            </Animated.View>
            <MenuBar />
          </View>

          <View>
            <View className="mt-[20px]">
              <TextSlider />
            </View>

            <View style={{ marginTop: 40 }}>
              <Navbar />
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default Index;

const styles = StyleSheet.create({
  container: {
    marginTop: StatusBar.currentHeight + 10,
    paddingHorizontal: 20,
  },
});
