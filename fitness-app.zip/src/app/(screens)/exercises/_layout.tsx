import { Stack, useGlobalSearchParams } from "expo-router";

const Layout = () => {
  const { exerciseId } = useGlobalSearchParams<{ exerciseId: string }>();

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="modal"
        options={{ presentation: "modal", animation: "slide_from_bottom" }}
        initialParams={{ exerciseId: exerciseId }}
      />
    </Stack>
  );
};

export default Layout;
