export const APPWRITE_ENDPOINT = "https://cloud.appwrite.io/v1";
export const APPWRITE_PROJECT_ID = "65bb97793474dccbab68";
export const DATABASE_ID = "65bb97bf3e85c78f44b1";
export const COLLECTION_CATEGORY = "65bb97e2d8facc820e09";
export const COLLECTION_EXERCISES = "65d5d0965f57d87f0b71";
export const COLLECTION_MYWORKOUTS = "65d604a866d80b059615";
