export const colors = {
  primaryRed: "#ff7878",
};