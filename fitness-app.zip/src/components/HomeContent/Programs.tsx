import { FC } from "react";
import { Text, View } from "react-native";

export const Programs: FC = () => {
  return (
    <View>
      <Text>Programs</Text>
    </View>
  );
};
