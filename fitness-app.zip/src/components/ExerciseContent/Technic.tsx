import { IExercises } from "@/interfaces/exercises.interface";
import { FC } from "react";
import { Text, View } from "react-native";

export const Technic: FC<{ exercise: IExercises[] }> = ({ exercise }) => {
  return (
    <View>
      {exercise?.map((item) => (
        <Text key={item.$id}>{item.technics}</Text>
      ))}
    </View>
  );
};
