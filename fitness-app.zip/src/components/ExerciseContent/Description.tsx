import { IExercises } from "@/interfaces/exercises.interface";
import { FC } from "react";
import { Text, View } from "react-native";

export const Description: FC<{ exercise: IExercises[] }> = ({ exercise }) => {
  return (
    <View className="">
      {exercise?.map((item) => (
        <>
          <Text key={item.$id}>{item.description}</Text>
        </>
      ))}
    </View>
  );
};
