import { Models } from "appwrite";

export interface IUser {
  name: string;
  email: string;
  id: string
}
