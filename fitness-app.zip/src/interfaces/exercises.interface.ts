import { Models } from "appwrite";

export interface IExercises extends Models.Document {
  name: string;
  description: string;
  img: string[];
  muscles: string;
  technics: string;
  mistakes: string;
}
