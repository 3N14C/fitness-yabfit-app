export interface ILoginDto {
  email: string;
  password: string;
}
