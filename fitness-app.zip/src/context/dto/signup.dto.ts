export interface ISignupDto {
  username: string;
  email: string;
  password: string;
}
